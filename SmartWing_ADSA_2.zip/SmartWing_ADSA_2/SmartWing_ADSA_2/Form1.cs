﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace SmartWing_ADSA_2
{
    public partial class Form1 : Form
    {
        private Graphics graph; 

        public Form1()
        {
            InitializeComponent();
        }

        private void chart1_Click(object sender, EventArgs e)
        {
            Random rdn = new Random();
            for (int i = 0; i < 50; i++)
            {
                chart1.Series["test"].Points.AddXY
                                (rdn.Next(0, 10), rdn.Next(0, 10));

            }

            chart1.Series["test"].ChartType =
                       SeriesChartType.FastLine;
            chart1.Series["test"].Color = Color.Red;


        }
    }
}